export interface CSVData {
  headers: string[];
  rows: Record<string, any>[];
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  type?: 'text' | 'chart' | 'table';
  data?: any;
}
