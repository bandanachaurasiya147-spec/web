/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import Papa from 'papaparse';
import { 
  Upload, 
  Send, 
  FileText, 
  BarChart3, 
  Table as TableIcon, 
  MessageSquare, 
  Loader2,
  Database,
  Sparkles,
  ArrowRight,
  Layers,
  Zap,
  LayoutDashboard
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  LineChart,
  Line,
  Legend,
  AreaChart,
  Area
} from 'recharts';
import Markdown from 'react-markdown';
import { cn } from './lib/utils';
import { CSVData, Message } from './types';

const COLORS = ['#10b981', '#6366f1', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

export default function App() {
  const [csvData, setCsvData] = useState<CSVData | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    Papa.parse(file, {
      header: true,
      dynamicTyping: true,
      skipEmptyLines: true,
      complete: (results) => {
        const headers = results.meta.fields || [];
        const rows = results.data as Record<string, any>[];
        setCsvData({ headers, rows });
        setIsUploading(false);
        
        setMessages([{
          id: 'welcome',
          role: 'assistant',
          content: `### Data Ingested Successfully\n\nI've analyzed **${file.name}**. It contains **${rows.length}** records across **${headers.length}** dimensions.\n\nWhat would you like to explore first? I can generate visualizations, identify outliers, or summarize key metrics for you.`,
          timestamp: new Date()
        }]);
      },
      error: (error) => {
        console.error('CSV Parsing Error:', error);
        setIsUploading(false);
        alert('Failed to parse CSV file.');
      }
    });
  };

  const handleSendMessage = async () => {
    if (!input.trim() || !csvData || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const dataSample = csvData.rows.slice(0, 100);
      const dataContext = JSON.stringify(dataSample);
      const headers = csvData.headers.join(', ');

      const systemInstruction = `
        You are a high-end data intelligence agent. 
        Context: CSV with columns [${headers}]. Total records: ${csvData.rows.length}.
        Sample Data: ${dataContext}.

        Output Guidelines:
        1. Use professional, sophisticated language.
        2. Provide deep insights, not just surface-level descriptions.
        3. For visualizations, use the "json-viz" code block.
        4. JSON Structure: { "type": "bar"|"pie"|"line"|"area"|"table", "title": string, "data": array, "explanation": string }
        5. For "area" charts, use the same structure as "line".
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: input,
        config: { systemInstruction }
      });

      const aiContent = response.text || "Analysis failed to generate.";
      const vizMatch = aiContent.match(/```json-viz\n([\s\S]*?)\n```/);
      let vizData = null;
      let cleanContent = aiContent;

      if (vizMatch) {
        try {
          vizData = JSON.parse(vizMatch[1]);
          cleanContent = aiContent.replace(/```json-viz\n[\s\S]*?\n```/, '').trim();
        } catch (e) {
          console.error('Viz parse error', e);
        }
      }

      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: cleanContent,
        timestamp: new Date(),
        type: vizData?.type,
        data: vizData
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'assistant',
        content: "An intelligence error occurred. Please re-attempt.",
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const renderVisualization = (msg: Message) => {
    if (!msg.data) return null;
    const { type, data, title } = msg.data;

    const ChartContainer = ({ children, title }: { children: React.ReactNode, title: string }) => (
      <div className="w-full mt-6 glass rounded-2xl p-6 border-white/5 shadow-2xl">
        <div className="flex items-center justify-between mb-6">
          <h4 className="text-sm font-bold tracking-widest uppercase text-slate-400 flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-400" />
            {title}
          </h4>
          <div className="flex gap-1">
            <div className="w-2 h-2 rounded-full bg-emerald-500/20" />
            <div className="w-2 h-2 rounded-full bg-indigo-500/20" />
          </div>
        </div>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            {children as React.ReactElement}
          </ResponsiveContainer>
        </div>
      </div>
    );

    const commonAxisProps = {
      fontSize: 10,
      tickLine: false,
      axisLine: false,
      stroke: "#64748b",
    };

    switch (type) {
      case 'bar':
        return (
          <ChartContainer title={title}>
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
              <XAxis dataKey="name" {...commonAxisProps} />
              <YAxis {...commonAxisProps} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }}
                itemStyle={{ color: '#fff' }}
              />
              <Bar dataKey="value" fill="url(#barGradient)" radius={[6, 6, 0, 0]}>
                <defs>
                  <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" />
                    <stop offset="100%" stopColor="#059669" />
                  </linearGradient>
                </defs>
              </Bar>
            </BarChart>
          </ChartContainer>
        );
      case 'area':
      case 'line':
        return (
          <ChartContainer title={title}>
            <AreaChart data={data}>
              <defs>
                <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
              <XAxis dataKey="name" {...commonAxisProps} />
              <YAxis {...commonAxisProps} />
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }} />
              <Area type="monotone" dataKey="value" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorValue)" />
            </AreaChart>
          </ChartContainer>
        );
      case 'pie':
        return (
          <ChartContainer title={title}>
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={8}
                dataKey="value"
              >
                {data.map((_: any, index: number) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} stroke="none" />
                ))}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }} />
              <Legend verticalAlign="bottom" height={36} iconType="circle" />
            </PieChart>
          </ChartContainer>
        );
      case 'table':
        return (
          <div className="w-full mt-6 glass rounded-2xl overflow-hidden border-white/5 shadow-2xl">
            <div className="p-4 border-b border-white/5 bg-white/5">
              <h4 className="text-xs font-bold tracking-widest uppercase text-slate-400">{title}</h4>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-900/50 text-slate-400 font-bold uppercase tracking-tighter">
                  <tr>
                    {Object.keys(data[0] || {}).map(key => (
                      <th key={key} className="px-6 py-4">{key}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {data.map((row: any, i: number) => (
                    <tr key={i} className="hover:bg-white/5 transition-colors">
                      {Object.values(row).map((val: any, j) => (
                        <td key={j} className="px-6 py-4 text-slate-300 font-mono">{val}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-emerald-500/30">
      {/* Navigation */}
      <nav className="h-20 glass-dark sticky top-0 z-50 px-8 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-emerald-500 to-indigo-500 rounded-xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
            <div className="relative w-12 h-12 bg-slate-900 rounded-xl flex items-center justify-center border border-white/10">
              <Sparkles className="text-emerald-400 w-6 h-6" />
            </div>
          </div>
          <div>
            <h1 className="font-serif text-2xl font-bold tracking-tight text-white italic">Insight.AI</h1>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] font-bold tracking-[0.2em] uppercase text-slate-500">Neural Data Engine</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-6">
          {csvData && (
            <div className="hidden md:flex items-center gap-6 px-6 py-2 glass rounded-full">
              <div className="flex flex-col">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Records</span>
                <span className="text-sm font-mono text-emerald-400">{csvData.rows.length.toLocaleString()}</span>
              </div>
              <div className="w-px h-6 bg-white/10" />
              <div className="flex flex-col">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Dimensions</span>
                <span className="text-sm font-mono text-indigo-400">{csvData.headers.length}</span>
              </div>
            </div>
          )}
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="group relative px-6 py-3 bg-white text-slate-950 rounded-full text-sm font-bold overflow-hidden transition-all hover:scale-105 active:scale-95"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-emerald-400 to-indigo-400 opacity-0 group-hover:opacity-100 transition-opacity" />
            <span className="relative flex items-center gap-2 group-hover:text-white transition-colors">
              <Upload className="w-4 h-4" />
              {csvData ? 'Replace Dataset' : 'Ingest CSV'}
            </span>
          </button>
          <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept=".csv" className="hidden" />
        </div>
      </nav>

      <main className="flex-1 flex flex-col max-w-6xl mx-auto w-full p-6 lg:p-12 gap-12">
        {!csvData ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center space-y-12 py-12">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative"
            >
              <div className="absolute -inset-12 bg-emerald-500/10 blur-3xl rounded-full" />
              <h2 className="text-6xl lg:text-8xl font-serif font-black tracking-tighter text-white leading-none">
                Data speaks.<br />
                <span className="text-gradient italic">We translate.</span>
              </h2>
            </motion.div>
            
            <p className="text-slate-400 text-lg max-w-2xl mx-auto font-medium leading-relaxed">
              Experience the next generation of data analysis. Upload your complex datasets and interact with our neural engine to uncover hidden patterns instantly.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-4xl">
              {[
                { icon: Zap, title: "Instant Synthesis", desc: "Real-time data processing and insight generation." },
                { icon: LayoutDashboard, title: "Neural Viz", desc: "AI-driven visualizations that adapt to your data." },
                { icon: Database, title: "Secure Ingest", desc: "Enterprise-grade local processing for your sensitive data." }
              ].map((f, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="p-8 glass rounded-3xl text-left group hover:border-white/20 transition-all"
                >
                  <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-emerald-500/10 transition-colors">
                    <f.icon className="w-6 h-6 text-emerald-400" />
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2">{f.title}</h3>
                  <p className="text-sm text-slate-500 leading-relaxed">{f.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col lg:flex-row gap-8 overflow-hidden">
            {/* Chat Interface */}
            <div className="flex-1 flex flex-col glass rounded-[2.5rem] overflow-hidden shadow-2xl border-white/5">
              <div className="flex-1 overflow-y-auto p-8 space-y-8 scrollbar-thin scrollbar-thumb-white/10">
                <AnimatePresence initial={false}>
                  {messages.map((msg) => (
                    <motion.div
                      key={msg.id}
                      initial={{ opacity: 0, x: msg.role === 'user' ? 20 : -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className={cn(
                        "flex flex-col max-w-[90%]",
                        msg.role === 'user' ? "ml-auto items-end" : "items-start"
                      )}
                    >
                      <div className={cn(
                        "px-6 py-4 rounded-3xl text-sm leading-relaxed",
                        msg.role === 'user' 
                          ? "bg-gradient-to-br from-emerald-500 to-emerald-700 text-white rounded-tr-none shadow-lg shadow-emerald-500/20" 
                          : "glass-dark text-slate-200 rounded-tl-none border-white/10"
                      )}>
                        <div className="prose prose-invert prose-sm max-w-none">
                          <Markdown>{msg.content}</Markdown>
                        </div>
                        {renderVisualization(msg)}
                      </div>
                      <span className="text-[9px] font-bold tracking-widest text-slate-600 mt-2 uppercase px-2">
                        {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </motion.div>
                  ))}
                </AnimatePresence>
                {isLoading && (
                  <div className="flex items-center gap-4 text-emerald-400">
                    <div className="w-10 h-10 glass rounded-full flex items-center justify-center">
                      <Loader2 className="w-5 h-5 animate-spin" />
                    </div>
                    <span className="text-[10px] font-bold tracking-[0.3em] uppercase animate-pulse">Processing Intelligence</span>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>

              {/* Input Area */}
              <div className="p-8 bg-black/20 border-t border-white/5">
                <div className="relative group">
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-emerald-500/20 to-indigo-500/20 rounded-2xl blur opacity-0 group-focus-within:opacity-100 transition duration-500"></div>
                  <div className="relative flex items-center gap-3">
                    <input
                      type="text"
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                      placeholder="Query the neural engine..."
                      className="flex-1 glass-dark rounded-2xl px-6 py-4 text-sm text-white placeholder:text-slate-600 focus:outline-none border-white/5 focus:border-emerald-500/50 transition-all"
                    />
                    <button
                      onClick={handleSendMessage}
                      disabled={!input.trim() || isLoading}
                      className="p-4 bg-white text-slate-950 rounded-2xl hover:bg-emerald-400 hover:text-white disabled:opacity-20 transition-all active:scale-90 shadow-xl"
                    >
                      <ArrowRight className="w-5 h-5" />
                    </button>
                  </div>
                </div>
                <div className="mt-6 flex flex-wrap gap-3">
                  {[
                    "Executive Summary",
                    "Predictive Trends",
                    "Anomaly Detection",
                    "Visual Deep-Dive"
                  ].map((s) => (
                    <button
                      key={s}
                      onClick={() => setInput(s)}
                      className="text-[9px] font-black tracking-[0.2em] uppercase text-slate-500 hover:text-emerald-400 transition-colors"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Ingesting Overlay */}
      <AnimatePresence>
        {isUploading && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-950/90 backdrop-blur-2xl z-[100] flex items-center justify-center"
          >
            <div className="flex flex-col items-center gap-8">
              <div className="relative w-24 h-24">
                <div className="absolute inset-0 border-4 border-emerald-500/10 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Database className="w-8 h-8 text-emerald-400 animate-pulse" />
                </div>
              </div>
              <div className="text-center">
                <h3 className="text-2xl font-serif italic text-white mb-2">Synchronizing Data</h3>
                <p className="text-[10px] font-bold tracking-[0.4em] uppercase text-slate-500">Neural Mapping in Progress</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
